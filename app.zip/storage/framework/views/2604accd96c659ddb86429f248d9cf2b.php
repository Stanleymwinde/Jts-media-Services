<div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
    <p>Here are the details of the submission:</p>
    <ul>
        <li>Name: <?php echo e($data['name']); ?></li>
        <li>Email: <?php echo e($data['email']); ?></li>
        <li>phone: <?php echo e($data['phone']); ?></li>
        <li>Message: <?php echo e($data['message']); ?></li>
    </ul>
    
</div>
<?php /**PATH F:\Kenbras\Jts\resources\views/user/emailsub.blade.php ENDPATH**/ ?>